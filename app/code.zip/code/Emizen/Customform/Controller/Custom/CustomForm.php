<?php
namespace emizen\customform\Controller\Add;

use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\ResultFactory;

class Index extends Action
{
    protected $customform;

    public function __construct(
	\Magento\Framework\App\Action\Context $context,
    \Emizen\Customform\Model\Customform $customform
    )
    {
        parent::__construct($context);
        $this->customform = $customform;
    }

    public function execute()
	{
	   $name = $this->getRequest()->getPostValue("name");
           $fname = $this->getRequest()->getPostValue("father_name");
           $dob = $this->getRequest()->getPostValue("dob");
           $this->customform 
             	->setName($name);
		        ->setFatherName($fname);
		        ->setDob($dob);
		        ->save();
            $redirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            $redirect->setUrl($this->_redirect->getRefererUrl());
            return $redirect;
	}
}
