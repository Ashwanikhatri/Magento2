<?php

namespace Emizen\Customform\Model\ResourceModel\Customform;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Emizen\Customform\Model\Customform', 'Emizen\Customform\Model\ResourceModel\Customform');
        $this->_map['fields']['page_id'] = 'main_table.page_id';
    }

}
?>